##i=1  
##n=int(input("Enter the number up to which you want to print the natural numbers?"))  
##for i in range(0,n):  
##    print(i,end = '')
##
##
##
##
##
##
##
##
##
##
##
##
##
##i=1;  
##num = int(input("Enter a number:"));  
##for i in range(1,11):  
##    print("%d X %d = %d"%(num,i,num*i));
##
##
##
##
##
##    n = int(input("Enter the number of rows you want to print?"))  
##i,j=0,0  
##for i in range(0,n):  
##    print()  
##    for j in range(0,i+1):  
##        print("*",end="")
##
##
##
##
##
##
##for i in range(0,5):  
##    print(i)  
##else:print("for loop completely exhausted, since there is no break.");
##
##
##
##
##
for i in range(0,5):  
    print(i)  
    break;  
else:print("for loop is exhausted");  
print("The loop is broken due to break statement...came out of loop")  

