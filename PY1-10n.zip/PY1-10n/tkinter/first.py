# !/usr/bin/python3  
from tkinter import *  
  
#creating the application main window.   
top = Tk()  
  
#Entering the event main loop  
top.mainloop() 
