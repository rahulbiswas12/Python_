print("Hello");
print("World")
