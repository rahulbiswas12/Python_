##import platform
##import datetime
##print(platform.sys.version)
##d=datetime.datetime.now()
##print(d)
##
##
######fname = input("Input your First Name : ")
####lname = input("Input your Last Name : ")
####print ("Hello  " + lname + " " + fname)
##name="  Python    "
##print(name)
##
##print(name.strip())


Name="Python"
del Name
print (Name)
