# Concatenaton of tuples 
Tuple1 = (0, 1, 2, 3) 
Tuple2 = ('Python', 'For', 'SIT') 

Tuple3 = Tuple1 + Tuple2 

# Printing first Tuple 
print("Tuple 1: ") 
print(Tuple1) 

# Printing Second Tuple 
print("\nTuple2: ") 
print(Tuple2) 

# Printing Final Tuple 
print("\nTuples after Concatenaton: ") 
print(Tuple3) 
