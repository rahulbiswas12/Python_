list1 = [ ('Cat', 'Bat'), ('Sat', 'Cat'), ('Cat', 'Bat'), ('Cat', 'Bat', 'Sat'), [1, 2], [1, 2, 3], [1, 2] ] 
print(list1.count(('Cat', 'Bat')))
