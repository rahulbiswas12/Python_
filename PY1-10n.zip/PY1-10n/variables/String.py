##str1 = 'hello SIT' #string str1  
##str2 = ' how are you' #string str2  
##print (str1[0:2]) #printing first two character using slice operator
##print(str1[2:5])
##print(str1.strip())
##print(len(str1))
##print(str1.lower())
##print(str1.upper())
##print(str1.replace("H", "J"))
##print (str1[4]) #printing 4th character of the string  
##print (str1*2) #printing the string twice  
##print (str1 + str2) #printing the concatenation of str1 and str2
##
##print (str1[-2])
##
##print(2+2+10%3)
##
##
##
##del str1
##print (str1)
str1 = 'hello SIT'
print(str1.title)
