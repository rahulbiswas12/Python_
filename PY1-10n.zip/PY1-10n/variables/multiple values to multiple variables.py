a,b,c=5,10,15  
print (a);  
print (b);  
print (c);  
