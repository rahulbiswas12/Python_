x = 5
y = "John"
print(x)
print(y)


##x = 4 # x is of type int
##x = "Sally" # x is now of type str
##print(x)

##x = "awesome"
##print("Python is " + x)



##x = "Python is "
##y = "awesome"
##z =  x + y
##print(z)

##x = 5
##y = 10
##print(x + y)


x = 5
y = "John"
print(x + y)
