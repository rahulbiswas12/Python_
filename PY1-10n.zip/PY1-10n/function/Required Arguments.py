##
###the argument name is the required argument to the function func   
##def func(name):  
##    message = "Hi "+name;  
##    return message;  
##name = input("Enter the name?")  
##print(func(name)) 
##
##
### In[6]:
##
##
###the function simple_interest accepts three arguments and returns the simple interest accordingly  
##def simple_interest(p,t,r):  
##    return (p*t*r)/100  
##p = float(input("Enter the principle amount? "))  
##r = float(input("Enter the rate of interest? "))  
##t = float(input("Enter the time in years? "))  
##print("Simple Interest: ",simple_interest(p,r,t)) 
##
##
### In[7]:
##
##
#the function calculate returns the sum of two arguments a and b  
def calculate(a,b):  
    return a+b  
calculate(10) # this causes an error as we are missing a required arguments b.  
##
##
### In[ ]:
##
##
##
##
##
### In[ ]:
##
##
##
##
