#!/usr/bin/env python
# coding: utf-8

# In[3]:


def hello_world():  
    print("hello world")  
  
hello_world() 


# In[6]:


#defining the function  
def func (name):  
    print("Hi ",name);  
  
#calling the function   
func("Debasish") 


# In[ ]:





# In[ ]:




