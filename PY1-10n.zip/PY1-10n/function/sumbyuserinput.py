#!/usr/bin/env python
# coding: utf-8

# In[1]:


#python function to calculate the sum of two variables   
#defining the function  
def sum (a,b):  
    return a+b;  
  
#taking values from the user  
a = int(input("Enter a: "))  
b = int(input("Enter b: "))  
  
#printing the sum of a and b  
print("Sum = ",sum(a,b))  


# In[ ]:




