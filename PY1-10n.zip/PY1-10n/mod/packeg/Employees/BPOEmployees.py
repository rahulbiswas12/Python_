def getBPONames():  
    List = ["ABOP", "BBPO", "CBPO"]  
    return List;  
