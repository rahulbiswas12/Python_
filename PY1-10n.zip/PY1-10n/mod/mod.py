#displayMsg prints a message to the name being passed.   
def displayMsg(name): 
    print("Hi "+name)
