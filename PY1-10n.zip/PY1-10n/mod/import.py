import mod;  
name = input("Enter the name?")  
mod.displayMsg(name)  
